function R = Euler2Rotation(phi, theta, psi)
    % rotation is body to inertial frame
    R = 
end